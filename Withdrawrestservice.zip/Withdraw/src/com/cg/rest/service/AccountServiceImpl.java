package com.cg.rest.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.rest.dao.IAccountDao;

@Service("empservice")
@Transactional
public class AccountServiceImpl implements IAccountService {

	@Autowired
	IAccountDao empdao;

	@Override
	public double withdraw(int accountId, double balance) {
	
		return empdao.withdraw(accountId, balance);
	}

}
