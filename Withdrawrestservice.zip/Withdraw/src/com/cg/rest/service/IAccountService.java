package com.cg.rest.service;


public interface IAccountService {

	public double withdraw(int accountId,double balance);
	
}
