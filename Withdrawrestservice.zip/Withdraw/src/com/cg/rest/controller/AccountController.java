package com.cg.rest.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.rest.service.IAccountService;

@RestController
public class AccountController {
	@Autowired
	IAccountService empservice;

	@RequestMapping(value = "/withdraw/{accountId}/{balance}", headers="Accept=*/*",method = RequestMethod.GET)
	public String deleteEmployee(@PathVariable("accountId") int id,@PathVariable("balance") double amount) {
	System.out.println(id);
	empservice.withdraw(id, amount);
	return "successful";
   }
	
}
