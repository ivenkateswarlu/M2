package com.cg.rest.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.rest.entity.AccountBean;

@Repository("empdao")
public class AccountDaoImpl implements IAccountDao {

	@PersistenceContext
	EntityManager em;
	@Override
	public double withdraw(int accountId, double balance) {
	
		AccountBean accountBean=em.find(AccountBean.class, accountId);
		System.out.println(accountBean);
		accountBean.setBalance(accountBean.getBalance() - balance);
		
	
		em.merge(accountBean);
		System.out.println(accountBean);
		em.flush();
		
		return accountBean.getBalance();
	}

	
	
}
