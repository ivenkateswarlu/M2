package com.cg.rest.dao;


public interface IAccountDao {

	public double withdraw(int accountId,double balance);
	
}
