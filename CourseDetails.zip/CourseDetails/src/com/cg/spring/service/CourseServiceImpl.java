package com.cg.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.spring.dao.ICourseDAO;
import com.cg.spring.dto.Course;


@Service
@Transactional
public class CourseServiceImpl  implements ICourseService{

	@Autowired
	ICourseDAO dao;
	
	@Override
	public List<Course> getallCourseDetails() {
		// TODO Auto-generated method stub
		return dao.getallCourseDetails();
	}

	@Override
	public String getCourseName() {
		// TODO Auto-generated method stub
		return dao.getCourseName();
	}

}
