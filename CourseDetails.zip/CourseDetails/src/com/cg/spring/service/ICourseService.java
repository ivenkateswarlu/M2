package com.cg.spring.service;

import java.util.List;

import com.cg.spring.dto.Course;

public interface ICourseService {
	
	List<Course> getallCourseDetails();
	public String getCourseName();

}
