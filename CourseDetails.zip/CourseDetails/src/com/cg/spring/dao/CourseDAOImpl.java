package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.spring.dto.Course;

@Repository("coursedao")
public class CourseDAOImpl  implements ICourseDAO{

	@PersistenceContext
	EntityManager entitymanger;
	
	@Override
	public List<Course> getallCourseDetails() {
		// TODO Auto-generated method stub
		
		Query query=entitymanger.createQuery(" select c FROM Course c");
		List<Course> myList=query.getResultList();
		return myList;
		
		
	}

	@Override
	public String getCourseName() {
		// TODO Auto-generated method stub
	
		
		Query query1=entitymanger.createQuery("Select c_name from Course course where c_id=1 ");
		String courseName=(String) query1.getSingleResult();
		return courseName;
	
	}

}
