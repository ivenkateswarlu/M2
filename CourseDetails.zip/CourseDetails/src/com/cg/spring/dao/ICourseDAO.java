package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.dto.Course;


public interface ICourseDAO {

	
	List<Course> getallCourseDetails();
	public String getCourseName();

}
