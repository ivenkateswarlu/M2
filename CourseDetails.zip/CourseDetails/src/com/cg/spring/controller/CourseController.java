package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.spring.dto.Course;
import com.cg.spring.service.ICourseService;
@Controller
public class CourseController {
	@Autowired
	ICourseService courseService;
	
   @RequestMapping(value="all")
	public String getAll(){
		return "coursedetails";
		
	}
 
   @RequestMapping(value="course")
	public String coursepage(Model model) {
	  
		List<Course> list = courseService.getallCourseDetails();
		model.addAttribute("coursedetails", list);
		return "course";
	}  
   @RequestMapping("/enroll")
	public String registrationPage(Model model) {
		String view = "";
		String name = courseService.getCourseName();
		model.addAttribute("Coursename", name);
		view = "Sucess";
		return view;
	}
	
	
}
