package com.cg.course.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.course.dto.CourseDetails;
@Repository
public class CourseDaoImpl implements ICourseDao {
	@PersistenceContext
	EntityManager em;

	@Override
	public List<CourseDetails> display() {
		Query query = em.createQuery("select c from CourseDetails c");
		List<CourseDetails> list = query.getResultList();
		return list;
	}

}
