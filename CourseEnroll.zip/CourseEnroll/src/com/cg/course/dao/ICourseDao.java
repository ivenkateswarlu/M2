package com.cg.course.dao;

import java.util.List;

import com.cg.course.dto.CourseDetails;


public interface ICourseDao {

	List<CourseDetails> display();
}
