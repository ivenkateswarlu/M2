package com.cg.course.service;

import java.util.List;

import com.cg.course.dto.CourseDetails;

public interface ICourseService {
	List<CourseDetails> display();

}
