package com.cg.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.course.dto.CourseDetails;
import com.cg.course.service.ICourseService;


@Controller
public class MyController {
	
	@Autowired
	ICourseService service;
	
	@RequestMapping(value="all")
	public String link(){
		return "home";
		
	} 
	@RequestMapping(value="display")
	public String display(Model model){
		List<CourseDetails> list = service.display();
		model.addAttribute("temp", list);
		return "display";
	} 
	
	@RequestMapping(value="enroll")
	public ModelAndView display1( @ModelAttribute("my") CourseDetails courseDetails){
		 
		
		int id=courseDetails.getC_id();
		
		return new ModelAndView("success","my",id);
				
	} 
	
	
	
	

}
