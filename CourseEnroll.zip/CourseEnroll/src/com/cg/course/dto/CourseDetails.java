package com.cg.course.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="courseEnroll")
public class CourseDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int c_id;
	@Column
	private String c_name;
	@Column
	private Double c_fee;
	
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int c_id) {
		this.c_id = c_id;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public Double getC_fee() {
		return c_fee;
	}
	public void setC_fee(Double c_fee) {
		this.c_fee = c_fee;
	}
	@Override
	public String toString() {
		return "CourseDetails [c_id=" + c_id + ", c_name=" + c_name
				+ ", c_fee=" + c_fee + "]";
	}
	
}
